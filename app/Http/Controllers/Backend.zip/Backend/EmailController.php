<?php

namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use App\Http\Requests\Backend\EmailRequest;
use App\Models\Email;



class EmailController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if (!\auth()->user()->ability('superAdmin', 'manage_contacts,show_email')) {
            return redirect('admin/index');
        }

        $emails = Email::orderBy('id', 'desc')->paginate(10);

        return view('backend.emails.index', compact('emails'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        if (!\auth()->user()->ability('superAdmin', 'manage_contacts,show_email')) {
            return redirect('admin/index');
        }

        return view('backend.emails.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(EmailRequest $request)
    {
        if (!\auth()->user()->ability('superAdmin', 'manage_contacts,show_email')) {
            return redirect('admin/index');
        }

        $input['type']      = $request->type;
        $input['email']      = $request->email;
        $input['status']    = $request->status;

        Email::create($input);

        return redirect()->route('admin.emails.index')->with([
            'message' => 'E-Mail Created Successfully',
            'alert-type' => 'success'
        ]);
    }


    public function show($id)
    {
        //
    }

    public function edit(Email $email)
    {
        if (!\auth()->user()->ability('superAdmin', 'manage_contacts,show_email')) {
            return redirect('admin/index');
        }

        return view('backend.emails.edit', compact('email'));
    }

    public function update(EmailRequest $request, Email $email)
    {
        if (!\auth()->user()->ability('superAdmin', 'manage_contacts,show_email')) {
            return redirect('admin/index');
        }

        $input['type']      = $request->type;
        $input['email']      = $request->email;
        $input['status']    = $request->status;

        $email->update($input);

        return redirect()->route('admin.emails.index')->with([
            'message' => 'E-Mail Updated Successfully',
            'alert-type' => 'success'
        ]);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Email $email)
    {
        if (!\auth()->user()->ability('superAdmin', 'manage_contacts,show_email')) {
            return redirect('admin/index');
        }

        $email->delete();

        return redirect()->route('admin.emails.index')->with([
            'message' => 'E-Mail Deleted Successfully',
            'alert-type' => 'success'
        ]);

    }



}

